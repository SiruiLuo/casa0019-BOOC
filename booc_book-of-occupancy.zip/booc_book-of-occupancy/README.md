# BoOC_Book of Occupancy

A Pen created on CodePen.io. Original URL: [https://codepen.io/TTrista/pen/gbYwwdY](https://codepen.io/TTrista/pen/gbYwwdY).

